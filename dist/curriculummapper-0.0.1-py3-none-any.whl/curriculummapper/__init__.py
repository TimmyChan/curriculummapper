#! Python3
from .curriculummapper import Course
from .curriculummapper import Curriculum
